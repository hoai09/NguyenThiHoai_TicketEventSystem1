using Microsoft.AspNetCore.Components.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;
using NguyenThiHoai_TicketEventSystem.Core.Models;
using NguyenThiHoai_TicketEventSystem.Data.Data;
using NguyenThiHoai_TicketEventSystem.Data.Repositories;
using NguyenThiHoai_TicketEventSystem.UseCases.EventUseCases;
using NguyenThiHoai_TicketEventSystem.UseCases.Interfaces;
using NguyenThiHoai_TicketEventSystem.UseCases.RegistrationUseCases;
using NguyenThiHoai_TicketEventSystem.Web1.Areas.Identity;


var builder = WebApplication.CreateBuilder(args);
var connectionString = builder.Configuration.GetConnectionString("DefaultConnection") ?? throw new InvalidOperationException("Connection string 'DefaultConnection' not found.");
builder.Services.AddDbContext<AppDbContext>(options => options.UseSqlServer(connectionString));
builder.Services.AddDefaultIdentity<ApplicationUser>(options => options.SignIn.RequireConfirmedAccount = false)
    .AddRoles<IdentityRole>()
    .AddEntityFrameworkStores<AppDbContext>();

builder.Services.AddDatabaseDeveloperPageExceptionFilter();
builder.Services.AddRazorPages();
builder.Services.AddServerSideBlazor();
builder.Services.AddScoped<AuthenticationStateProvider, RevalidatingIdentityAuthenticationStateProvider<ApplicationUser>>();

// Đăng ký REPOSITORIES
builder.Services.AddScoped<IEventRepository, EventRepository>();
builder.Services.AddScoped<IRegistrationRepository, RegistrationRepository>();

// Đăng ký USE CASES
builder.Services.AddTransient<GetAllEventsUseCase>();
builder.Services.AddTransient<GetEventByIdUseCase>();
builder.Services.AddTransient<CreateEventUseCase>();
builder.Services.AddTransient<UpdateEventUseCase>();
builder.Services.AddTransient<DeleteEventUseCase>();
builder.Services.AddTransient<RegisterForEventUseCase>();
builder.Services.AddTransient<UnregisterFromEventUseCase>();
builder.Services.AddTransient<GetRegistrationsForEventUseCase>();

var app = builder.Build();

// Seed data (tạo Roles và Admin user)
using (var scope = app.Services.CreateScope())
{
    var roleManager = scope.ServiceProvider.GetRequiredService<RoleManager<IdentityRole>>();
    var userManager = scope.ServiceProvider.GetRequiredService<UserManager<ApplicationUser>>();
    string[] roleNames = { "Admin", "User" };
    foreach (var roleName in roleNames)
    {
        if (!await roleManager.RoleExistsAsync(roleName))
        {
            await roleManager.CreateAsync(new IdentityRole(roleName));
        }
    }

    var adminEmail = "admin@example.com";
    if (await userManager.FindByEmailAsync(adminEmail) == null)
    {
        var adminUser = new ApplicationUser { UserName = adminEmail, Email = adminEmail, EmailConfirmed = true };
        var result = await userManager.CreateAsync(adminUser, "Admin@123");
        if (result.Succeeded)
        {
            await userManager.AddToRoleAsync(adminUser, "Admin");
        }
    }
}
    app.UseAuthentication();;
    app.Run();